

## Role & Access Security
- Hak akses Guru/Siswa ditentukan oleh session server.
- Siswa tidak dapat memakai endpoint manajemen Guru.
- Tambah/hapus materi, tugas, dan buku hanya dapat dilakukan oleh Guru.
- `/api/submissions` hanya dapat diakses Guru dan menampilkan seluruh pengumpulan.
- Siswa memakai `/api/my-submissions` dan hanya melihat pengumpulan miliknya sendiri.
- UI juga menyembunyikan kontrol Guru untuk akun Siswa.
