

## Manajemen Akun Siswa
- Hanya Guru yang dapat membuka menu **Siswa**.
- Guru dapat membuat akun siswa dengan nama, username, dan password.
- Guru dapat mengubah nama dan mereset password siswa.
- Guru dapat menghapus akun siswa.
- Siswa tidak dapat membuat akun siswa atau mengakses endpoint `/api/students`.
- Password disimpan menggunakan bcrypt hash, bukan teks biasa.
